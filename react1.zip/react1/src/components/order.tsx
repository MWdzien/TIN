type Order = {
    customerName: string | "";
    total: number;
}

export default Order;